# SupportDesk — модуль автоматической миграции

В архиве **только** `StartupMigration.cs` и эта инструкция. Готовой SQLite-базы нет.

## Подключение к существующему проекту

1. Скопируйте `StartupMigration.cs` в папку проекта рядом с `Program.cs`.
2. В Visual Studio включите файл в проект. Для старого `.csproj` (.NET Framework 4.8) добавьте в `<ItemGroup>` с другими `<Compile>`:

   ```xml
   <Compile Include="StartupMigration.cs" />
   ```

3. В `Program.cs` найдите `Main()`. После `Application.SetCompatibleTextRenderingDefault(false);`, **до** `Application.Run(new PreLoaderForm());` вставьте:

   ```csharp
   try
   {
       StartupMigration.Apply();
   }
   catch (Exception ex)
   {
       MessageBox.Show("Ошибка миграции базы данных: " + ex.Message,
           "SupportDesk", MessageBoxButtons.OK, MessageBoxIcon.Error);
       return;
   }
   ```

4. Убедитесь, что существующий `Database.connectionString` указывает на нужный `teh_db.db`, и проект ссылается на `System.Data.SQLite`.
5. Перед первым запуском **сохраните резервную копию** рабочей БД.

## Что делает модуль

- Создаёт недостающие таблицы SQLite.
- Добавляет данные в пустые разделы заявок, лицензий и инвентаря (в непустые не добавляет).
- Назначает заявки существующему пользователю с `groupUser=WORKER` через `Users.initials`.
- Если Worker отсутствует, заполнение заявок пропускается до последующего запуска, когда он появится.
- Учитывает выполненные шаги в `__SupportDeskMigrations` для предотвращения повторной вставки.
- Не требует отдельной демо-БД.

## Важные оговорки

Это миграция с **тестовым наполнением**, а не только обновление схемы. Применяйте к рабочей БД осознанно. Модуль не создаёт пользователей и не задаёт пароли. Файл не заменяет весь `Program.cs` или `.csproj`.
