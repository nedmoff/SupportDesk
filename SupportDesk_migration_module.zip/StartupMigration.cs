﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;

namespace SupportDesk
{
    /// <summary>Idempotent startup schema/data migration. Does not replace user databases.</summary>
    internal static class StartupMigration
    {
        private const string Schema = @"CREATE TABLE IF NOT EXISTS ""Users"" (""id"" INTEGER PRIMARY KEY AUTOINCREMENT, ""family"" TEXT DEFAULT '', ""name"" TEXT DEFAULT '', ""father"" TEXT DEFAULT '', ""initials"" TEXT DEFAULT '', ""gender"" TEXT DEFAULT '', ""number"" TEXT DEFAULT '', ""email"" TEXT DEFAULT '', ""depart"" TEXT DEFAULT '', ""position"" TEXT DEFAULT '', ""login"" TEXT DEFAULT '', ""pass"" TEXT DEFAULT '', ""groupUser"" TEXT DEFAULT '', ""image"" TEXT DEFAULT '', ""typeAccess"" TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS ""Requests"" (""id"" INTEGER PRIMARY KEY AUTOINCREMENT, ""theDate"" TEXT DEFAULT '', ""tema"" TEXT DEFAULT '', ""typeProblem"" TEXT DEFAULT '', ""userReq"" TEXT DEFAULT '', ""kabinet"" TEXT DEFAULT '', ""discription"" TEXT DEFAULT '', ""date"" TEXT DEFAULT '', ""time"" TEXT DEFAULT '', ""status"" TEXT DEFAULT '', ""executor"" TEXT DEFAULT '', ""executor2"" TEXT DEFAULT '', ""nameFile"" TEXT DEFAULT '', ""pathFile"" TEXT DEFAULT '', ""nameFileResult"" TEXT DEFAULT '', ""pathFileResult"" TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS ""Cartridges"" (""ID"" INTEGER PRIMARY KEY AUTOINCREMENT, ""Cabinet"" TEXT DEFAULT '', ""FIO"" TEXT DEFAULT '', ""NamePrinter"" TEXT DEFAULT '', ""Cartridge"" TEXT DEFAULT '', ""Date1"" TEXT DEFAULT '', ""Date2"" TEXT DEFAULT '', ""Date3"" TEXT DEFAULT '', ""Date4"" TEXT DEFAULT '', ""Date5"" TEXT DEFAULT '', ""Date6"" TEXT DEFAULT '', ""Date7"" TEXT DEFAULT '', ""Date8"" TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS ""Licenses"" (""ID"" INTEGER PRIMARY KEY AUTOINCREMENT, ""cabinet"" TEXT DEFAULT '', ""software"" TEXT DEFAULT '', ""check"" TEXT DEFAULT '', ""pdf"" TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS ""Inventory"" (""ID"" INTEGER PRIMARY KEY AUTOINCREMENT, ""name"" TEXT DEFAULT '', ""purchaseDate"" TEXT DEFAULT '', ""invNum"" TEXT DEFAULT '', ""amount"" TEXT DEFAULT '', ""location"" TEXT DEFAULT '', ""factLocation"" TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS ""Cabinets"" (""ID"" INTEGER PRIMARY KEY AUTOINCREMENT, ""cabinet"" TEXT DEFAULT '', ""licenses"" TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS ""TypeJob"" (""ID"" INTEGER PRIMARY KEY AUTOINCREMENT, ""typeJob"" TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS ""Departaments"" (""ID"" INTEGER PRIMARY KEY AUTOINCREMENT, ""depart"" TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS ""Positions"" (""ID"" INTEGER PRIMARY KEY AUTOINCREMENT, ""position"" TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS ""Status"" (""ID"" INTEGER PRIMARY KEY AUTOINCREMENT, ""status"" TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS ""Executors"" (""ID"" INTEGER PRIMARY KEY AUTOINCREMENT, ""initials"" TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS ""Passwords"" (""ID"" INTEGER PRIMARY KEY AUTOINCREMENT, ""Site"" TEXT DEFAULT '', ""Login"" TEXT DEFAULT '', ""Pass"" TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS ""Contacts"" (""ID"" INTEGER PRIMARY KEY AUTOINCREMENT, ""Company"" TEXT DEFAULT '', ""Name"" TEXT DEFAULT '', ""Phone"" TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS ""Roles"" (""id"" INTEGER PRIMARY KEY AUTOINCREMENT, ""role"" TEXT DEFAULT '', ""name"" TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS ""RightsRoles"" (""id"" INTEGER PRIMARY KEY AUTOINCREMENT, ""role"" TEXT DEFAULT '', ""name"" TEXT DEFAULT '', ""heightWindow"" TEXT DEFAULT '', ""avatar"" TEXT DEFAULT '', ""w_calendar"" TEXT DEFAULT '', ""w_users"" TEXT DEFAULT '', ""w_inventory"" TEXT DEFAULT '', ""f_typeJob"" TEXT DEFAULT '', ""f_cabinets"" TEXT DEFAULT '', ""f_status"" TEXT DEFAULT '', ""f_executor"" TEXT DEFAULT '', ""mnBtn_closeTicket"" TEXT DEFAULT '', ""mnBtn_createTicket"" TEXT DEFAULT '', ""mnBtn_calendar"" TEXT DEFAULT '', ""mnBtnMenu_about"" TEXT DEFAULT '', ""mnBtnMenu_settings"" TEXT DEFAULT '', ""mnBtnMenu_dataUser"" TEXT DEFAULT '', ""mnBtnMenu_logout"" TEXT DEFAULT '', ""btnMenu_users"" TEXT DEFAULT '', ""btnMenu_cartridges"" TEXT DEFAULT '', ""btnMenu_licenses"" TEXT DEFAULT '', ""btnMenu_inventory"" TEXT DEFAULT '', ""btnMenu_passwords"" TEXT DEFAULT '', ""btnMenu_contacts"" TEXT DEFAULT '', ""btnMenu_database"" TEXT DEFAULT '', ""btnMenu_excel"" TEXT DEFAULT '', ""btnMenu_createTicket"" TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS ""Functional"" (""id"" INTEGER PRIMARY KEY AUTOINCREMENT, ""role"" TEXT DEFAULT '', ""ticketUser"" TEXT DEFAULT '', ""ticketWorker"" TEXT DEFAULT '', ""ticketAdmin"" TEXT DEFAULT '', ""jobIsTicket"" TEXT DEFAULT '', ""signExecutors"" TEXT DEFAULT '');";
        public static void Apply()
        {
            using (var db = new SQLiteConnection(Database.connectionString))
            {
                db.Open();
                using (var transaction = db.BeginTransaction())
                {
                    // CREATE TABLE IF NOT EXISTS: compatible with existing databases.
                    foreach (var statement in Schema.Split(';'))
                        if (!string.IsNullOrWhiteSpace(statement))
                            Execute(db, transaction, statement);
                    Execute(db, transaction, "CREATE TABLE IF NOT EXISTS __SupportDeskMigrations (key TEXT PRIMARY KEY, appliedUtc TEXT NOT NULL)");
                    SeedReferences(db, transaction);
                    SeedInventory(db, transaction);
                    SeedLicenses(db, transaction);
                    SeedRequests(db, transaction);
                    transaction.Commit();
                }
            }
        }
        private static void Execute(SQLiteConnection db, SQLiteTransaction tx, string sql, params SQLiteParameter[] parameters)
        {
            using (var cmd = new SQLiteCommand(sql, db, tx))
            {
                cmd.Parameters.AddRange(parameters);
                cmd.ExecuteNonQuery();
            }
        }
        private static SQLiteParameter P(string name, object value) => new SQLiteParameter(name, value ?? DBNull.Value);
        private static bool IsDone(SQLiteConnection db, SQLiteTransaction tx, string key)
        {
            using (var cmd = new SQLiteCommand("SELECT COUNT(*) FROM __SupportDeskMigrations WHERE key = @key", db, tx))
            { cmd.Parameters.AddWithValue("@key", key); return Convert.ToInt32(cmd.ExecuteScalar()) > 0; }
        }
        private static void Mark(SQLiteConnection db, SQLiteTransaction tx, string key)
        { Execute(db, tx, "INSERT OR IGNORE INTO __SupportDeskMigrations(key, appliedUtc) VALUES(@key,@utc)", P("@key",key),P("@utc",DateTime.UtcNow.ToString("o"))); }
        private static int Count(SQLiteConnection db, SQLiteTransaction tx, string table)
        { using(var cmd=new SQLiteCommand("SELECT COUNT(*) FROM ["+table+"]",db,tx)) return Convert.ToInt32(cmd.ExecuteScalar()); }
        private static void SeedReferences(SQLiteConnection db, SQLiteTransaction tx)
        {
            if (IsDone(db,tx,"reference-v1")) return;
            if (Count(db,tx,"Cabinets") == 0)
                foreach(var room in new[]{"101","102","103","201","202","203","301","302"})
                    Execute(db,tx,"INSERT INTO Cabinets(cabinet,licenses) VALUES(@c,'')",P("@c",room));
            if (Count(db,tx,"TypeJob") == 0)
                foreach(var job in new[]{"Программное обеспечение","Оборудование","Сеть и интернет","Принтеры","Учётные записи"})
                    Execute(db,tx,"INSERT INTO TypeJob(typeJob) VALUES(@v)",P("@v",job));
            if (Count(db,tx,"Status") == 0)
                foreach(var status in new[]{"Новая","В работе","Выполнена","Закрыта"})
                    Execute(db,tx,"INSERT INTO Status(status) VALUES(@v)",P("@v",status));
            Mark(db,tx,"reference-v1");
        }
        private static void SeedInventory(SQLiteConnection db, SQLiteTransaction tx)
        {
            if(IsDone(db,tx,"inventory-v1")) return;
            // Only populate initially empty datasets; keep all real records intact.
            if(Count(db,tx,"Inventory") == 0)
            {
                string[] names={"Системный блок Dell OptiPlex","Монитор Philips 24","Ноутбук Lenovo ThinkPad","МФУ HP LaserJet","Коммутатор TP-Link 24 порта","ИБП APC 850VA","Точка доступа Wi-Fi","Проектор Epson","Сканер Canon","Монитор Samsung 27","ПК бухгалтерии","Сетевой принтер Brother"};
                for(int i=0;i<36;i++)
                {
                    var room=new[]{"101","102","103","201","202","203","301","302"}[i%8];
                    Execute(db,tx,"INSERT INTO Inventory(name,purchaseDate,invNum,amount,location,factLocation) VALUES(@n,@d,@inv,@a,@loc,@fact)",P("@n",names[i%names.Length]),P("@d",new DateTime(2022+i%4,1+i%12,5+i%22).ToString("dd.MM.yyyy")),P("@inv","SD-"+(10001+i)),P("@a","1"),P("@loc",room),P("@fact",room));
                }
            }
            Mark(db,tx,"inventory-v1");
        }
        private static void SeedLicenses(SQLiteConnection db, SQLiteTransaction tx)
        {
            if(IsDone(db,tx,"licenses-v1")) return;
            if(Count(db,tx,"Licenses") == 0)
            {
                string[] software={"Microsoft Office","Windows 11 Pro","7-Zip","Adobe Acrobat","Visual Studio","ESET Endpoint","AutoCAD","Microsoft 365","Kaspersky Endpoint","CorelDRAW"};
                for(int i=0;i<25;i++)
                    Execute(db,tx,"INSERT INTO Licenses(cabinet,software,[check],pdf) VALUES(@room,@soft,@check,@pdf)",P("@room",new[]{"101","102","103","201","202","203","301","302"}[i%8]),P("@soft",software[i%software.Length]),P("@check","Нет"),P("@pdf",""));
            }
            Mark(db,tx,"licenses-v1");
        }
        private static void SeedRequests(SQLiteConnection db, SQLiteTransaction tx)
        {
            if(IsDone(db,tx,"requests-v1")) return;
            // Never create credentials or assign somebody else's requests.
            var workers=new List<string>();
            using(var cmd=new SQLiteCommand("SELECT DISTINCT initials FROM Users WHERE UPPER(groupUser)='WORKER' AND initials IS NOT NULL AND TRIM(initials)<>''",db,tx))
            using(var rd=cmd.ExecuteReader()) while(rd.Read()) workers.Add(rd.GetString(0));
            if(workers.Count == 0) return; // retry at next launch, after a Worker exists
            if (Count(db,tx,"Executors") == 0)
                foreach(var worker in workers)
                    Execute(db,tx,"INSERT INTO Executors(initials) VALUES(@name)",P("@name",worker));
            if(Count(db,tx,"Requests") == 0)
            {
                string[] titles={"Не включается рабочий ПК","Не печатает принтер","Нет доступа к сети","Установить офисные приложения","Не работает сканер","Заменить картридж","Ошибка входа в учётную запись","Настроить почту","Медленная работа компьютера","Не подключается Wi-Fi","Проблема с монитором","Обновить программу"};
                string[] types={"Оборудование","Принтеры","Сеть и интернет","Программное обеспечение","Оборудование","Принтеры","Учётные записи","Программное обеспечение","Оборудование","Сеть и интернет","Оборудование","Программное обеспечение"};
                string[] statuses={"Новая","В работе","Выполнена"};
                for(int i=0;i<36;i++)
                {
                    var day=DateTime.Today.AddDays(-(i%28));
                    Execute(db,tx,@"INSERT INTO Requests(theDate,tema,typeProblem,userReq,kabinet,discription,date,time,status,executor,executor2,nameFile,pathFile,nameFileResult,pathFileResult)
                      VALUES(@when,@title,@type,@user,@room,@desc,@date,@time,@status,@worker,@worker2,'','','','')",
                      P("@when",day.ToString("dd.MM.yyyy HH:mm")),P("@title",titles[i%titles.Length]),P("@type",types[i%types.Length]),P("@user","Сотрудник "+(i+1)),P("@room",new[]{"101","102","103","201","202","203","301","302"}[i%8]),P("@desc","Тестовая заявка для проверки работы системы: "+titles[i%titles.Length]),P("@date",day.ToString("dd.MM.yyyy")),P("@time",day.ToString("dd.MM.yyyy")+"/09:00 - 10:00"),P("@status",statuses[i%3]),P("@worker",workers[i%workers.Count]),P("@worker2","Не назначен"));
                }
            }
            Mark(db,tx,"requests-v1");
        }
    }
}
